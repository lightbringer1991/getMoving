/* Open and close the FAQ overlay */

function openFAQ() {
    document.getElementById("faqOverlay").style.height = "100%";
}

function closeFAQ() {
    document.getElementById("faqOverlay").style.height = "0%";
}
