_____________________________________________________________________________________________________________
This directory contains scripts necessary for updating the database that run in the background on the server.
_____________________________________________________________________________________________________________

File descriptions:

### writeUrlData.py ###
Retrieves url source code and writes to a local file on the server.
Output is stored in the current directory.
A temporary file for semi-manual data handling that will be deleted when automatation of background scripts is implemented.
Please ensure you change the name of the output file within the script to ensure you don't overwrite other people's data
and make sure output files are deleted when no longer needed.

### wrapText.py ###
Retrieves url source code and adds string wrappers to the beggining and end of the response then writes to a local file in the current directory.
A temporary file for semi-manual data handling that will be deleted when automatation of background scripts is implemented.
Please ensure you change the name of the output file within the script to ensure you don't overwrite other people's data
and make sure output files are deleted when no longer needed.

### getCFAfeed.py ###
Retrieves CFA incidents rss feed, filters & reformats data then updates the relevant database table.
Currently in development. Please don't run this script yet... this is for Mel only for now.