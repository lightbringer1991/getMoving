import urllib

"""
Script to write data retrieved from a url to a local file
"""

# Get data from web site
# This is a sample url. Change it to the url you need.
response = urllib.urlopen('http://data.gov.au/dataset/f80007d1-fe53-4fa7-b021-991f0edd4a5c/resource/d83ed724-4dc9-48d8-af70-81f9c0dc341b/download/ballaratcurrentplanningapps.json')
text = response.read()

# Rename output file to anything you want
outfile = "writeUrlData.txt"

# Write wrapped string to file
f = open(outfile, "w")
f.write(text)
f.close()

# Display output in console... This is just for debugging purposes. Uncomment for console output. Delete or comment out from any automated scripts.
# print text
