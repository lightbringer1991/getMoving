"""
Script to reformat CFA rss feed to json and filter out incidents beyond a given radius from central Ballarat
"""

import xml.dom.minidom
import math
import json


# Define coordinates and radius distance for filtering incidents within a certain distance from Ballarat
ballaratLat = -37.56622
ballaratLong = 143.84957

ballaratLatRad = ballaratLat * (math.pi/180)
ballaratLongRad = ballaratLong * (math.pi/180)

# Radius currently set to 100km for development and debugging, as there is not always a current incident close to Ballarat
radiusDistance = 100 #km's

# Convert decimal to radians, necessary for distance calculations
def decimalToRadians(decimal):
	radians = decimal * (math.pi/180)
	return radians


# Calculate distance in km's between two locations
def getDistance(startLat, startLong, endLat, endLong):

	# Convert decimal latitude and longitude to radians
	startLat = decimalToRadians(startLat)
	startLong = decimalToRadians(startLong)
	endLat = decimalToRadians(endLat)
	endLong = decimalToRadians(endLong)

    # Measure distance from central point to incident location
	distance = math.acos(math.sin(startLat) * math.sin(endLat) + math.cos(startLat) * math.cos(endLat) * math.cos(endLong - (startLong))) * 6371

	return distance

# Extract additional field data from description string
def getDescriptionElement(text, start, end):
	return text[text.find(start)+len(start):text.find(end)]

def getLastDescriptionElement(text, start):
	return text[text.find(start)+len(start):]

# Strip html formatting embedded in text
def stripHtml(data):
    noInnerTags = data.replace('&lt;strong&gt;', '')
    noInnerTags = noInnerTags.replace('&lt;/strong&gt;', '')
    noInnerTags = noInnerTags.replace('&lt;br&gt;', '')

    return noInnerTags

# Parse XML filtering out unwanted data and convert to json
def createJson(data):
    cleanedData = stripHtml(data)
    dom = xml.dom.minidom.parseString(cleanedData)

    # Get all "item" nodes
    items = dom.getElementsByTagName("item")

    # First create a python dictionary to store key value pairs
    pythonData = []
    incidentData = {}

    # Traverse child nodes within each item node
    for item in items:

        # First check the location so we are only processing incidents in and around Ballarat

        # Incident location info is buried within the description node so we need to extract the location info from the description text first.
        description = item.getElementsByTagName("description")[0].childNodes[0].data

        latStart = 'Latitude: '
        latEnd = 'Longitude: '
        latitude = getDescriptionElement(description, latStart, latEnd)

        longStart = 'Longitude: '
        longEnd = ''
        longitude = getLastDescriptionElement(description, longStart)

        # Calculate distance in km's from central Ballarat to the incident, rounded to 2 decimal places
        incidentDistance = round(getDistance(ballaratLat, ballaratLong, float(latitude), float(longitude)), 2)

        # Only process incidents within a certain radius from central Ballarat
        if(incidentDistance <= radiusDistance):

            # Get the data from the xml nodes that we're interested in
            pubDate = item.getElementsByTagName("pubDate")[0].childNodes[0].data
            title = item.getElementsByTagName("title")[0].childNodes[0].data
            link = item.getElementsByTagName("link")[0].childNodes[0].data

            # Get additional values we need out of description string
            statusStart = 'Status: '
            statusEnd = 'Size: '
            status = getDescriptionElement(description, statusStart, statusEnd)

            sizeStart = 'Size: '
            sizeEnd = 'Vehicles: '
            size = getDescriptionElement(description, sizeStart, sizeEnd)

            typeStart = 'Type: '
            typeEnd = 'Location: '
            incidentType = getDescriptionElement(description, typeStart, typeEnd)

            locationStart = 'Location: '
            locationEnd = 'Status: '
            location = getDescriptionElement(description, locationStart, locationEnd)


            # Add data to python dictionaries
            incidentData['title'] = title
            incidentData['pubDate'] = pubDate
            incidentData['link'] = link
            incidentData['status'] = status
            incidentData['size'] = size
            incidentData['type'] = incidentType
            incidentData['location'] = location

            pythonData.append(dict(incidentData))

    # Convert python dict to json
    jsonData = json.dumps(pythonData)

    return jsonData




