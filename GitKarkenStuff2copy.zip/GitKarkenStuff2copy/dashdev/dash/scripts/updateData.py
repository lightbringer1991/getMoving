"""
Script to retrieve data from a url, apply special formatting if required and update the cached data in the database
	Note: This script is intended to run as a scheduled background job and therefore only handles updating of existing
	data, not insertion of new data.

	The database field being updated will only accept data in json format. If the data source is in a different format,
	an additional customised formatting script will be required to convert data to json. See comments on
	formatData() method below for more information.

Author: Melanie King
"""

# Python modules
import urllib
import sys
import datetime
import psycopg2

# Custom modules
# These modules must be stored in the same directory as this script.
import config

"""
IMPORTANT: This script requires a mandatory 1 argument and an optional 2nd argument when executed
	Arg 1: Name of the data source as it appears in the 'name' field of the dash_tile_data table in the database
	Arg 2: -f flag to indicate special formatting is required
"""

# Handle error logging
def logError(logMessage):

	# Get time of log message
	today = datetime.datetime.today()
	logTime = today.strftime('%d-%m-%Y %H:%M:%S')

	# format log message string
	logText = logTime + "\t" + logMessage + "\n"

	# Because error message should be on a single line with no spaces between lines
	logText = logText.replace("\n", "")
	logText = logText.strip(' ')

	# Write to log file
	f = open(config.logFile, "a")
	f.write(logText)
	f.close()

# Validate command line arguments provided
def validateArgs():
	if(len(sys.argv) < 2):
		logError("Incorrect number of arguments provided to updateData.py. Requires a minumum of 1 arguments")
		sys.exit()

	if(len(sys.argv) > 3):
		logError("Incorrect number of arguments provided to updateData.py. Requires a maximum of 2 arguments")
		sys.exit()

# Get data source url from the database
def getUrl(dataName):
	# Connect to the database
	try:
		conn = psycopg2.connect("dbname=%s user=%s host=%s password=%s" % (config.dbName, config.dbUser, config.dbHost, config.dbPass))
	except Exception,e:
		message = "Error connecting to database. Details: " + str(e)
		logError(message)
		sys.exit()

	# Create connection cursor
	cur = conn.cursor()

	try:
		cur.execute("SELECT url FROM dash_tile_data WHERE name=%s", (dataName,))
	except Exception,e:
		message = "Error querying the database. Details: " + str(e)
		logError(message)
		sys.exit()

	result = cur.fetchone()
	return str(result[0])

# Get data from url
def getData():
	# Retrieve url from the database
	url = getUrl(sys.argv[1])

	try:
		response = urllib.urlopen(url)
	except Exception,e:
		message = "Failed to retrieve url: " + url + " Details: " + str(e)
		logError(message)
		sys.exit()
	data = response.read()

	return data

# Apply special formatting and/or filtering
# Requires a separate formatting script for the data source in the current directory
# Naming of formatting script must be format_dataName.py
# The file name must be lowercase and dataName must match the 'name' field of the data source in the dash_tile table
# in the database exactly without spaces
# E.g. Name in database: Emergency Alerts  Formatting file name: format_emergencyalerts.py
def formatData(data):
	formatter = getFormattingScript()
	formattedData = formatter.createJson(data)

	return formattedData

# Load special formatting script for the specified tile
def getFormattingScript():
	data = sys.argv[1]
	dataName = data.lower()
	dataName = dataName.replace(" ", "")
	formatScript = "format_" + dataName
	formatter = __import__(formatScript)

	return formatter

# Update the tile's data in the database
# Requires an existing entry for the tile in the table dash_tile_data
def updateDatabase(data):

	# Connect to the database
	try:
		conn = psycopg2.connect("dbname=%s user=%s host=%s password=%s" % (config.dbName, config.dbUser, config.dbHost, config.dbPass))
	except Exception,e:
		message = "Error connecting to database. Details: " + str(e)
		logError(message)
		sys.exit()

	# Create connection cursor
	cur = conn.cursor()

	# This needs to be updated to tile id after database is normalised
	dataName = sys.argv[1]

	try:
		cur.execute("UPDATE dash_tile_data SET data=%s WHERE name=%s", (data, dataName))
	except Exception,e:
		message = "Error updating database. Details: " + str(e)
		logError(message)
		sys.exit()

	# Commit changes to update the database
	conn.commit()

def main():
	# Ensure the necessary arguments have been provided
	validateArgs()

	# Get data from the url stored in the database
	data = getData()

	# Apply reformatting if the -f flag was provided as arg 3
	if(len(sys.argv) == 3 and sys.argv[2] == "-f"):
		data = formatData(data)

	# Update the data field in the dash_tile_data table for the tile specified in arg 2
	# updateDatabase(data)
	print data

main()

