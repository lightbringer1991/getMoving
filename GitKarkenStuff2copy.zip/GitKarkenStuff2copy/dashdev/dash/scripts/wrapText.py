import urllib

"""
Script to add wrapper to string retrieved from url
"""

# Get data from web site
# This is a sample url. Change it to the url you need.
response = urllib.urlopen('http://data.gov.au/dataset/f80007d1-fe53-4fa7-b021-991f0edd4a5c/resource/d83ed724-4dc9-48d8-af70-81f9c0dc341b/download/ballaratcurrentplanningapps.json')
text = response.read()

# Add custom text to start and end of retrieved data
wrapperStart = "{{{ TEXT YOU WANT AT START }}}"
wrapperEnd = "{{{ TEXT YOU WANT AT END }}}"

wrappedText = wrapperStart + text + wrapperEnd

# Rename output file to anything you want
outfile = "wrappedFile.txt"

# Write wrapped string to file
f = open(outfile, "w")
f.write(wrappedText)
f.close()

# Display output in console... This is just for debugging purposes. Should deleted from any automated scripts.
print wrappedText
