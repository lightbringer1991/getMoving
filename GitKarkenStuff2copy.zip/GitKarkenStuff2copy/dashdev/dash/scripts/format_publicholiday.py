"""
Script to convert CSV data to JSON
"""

import json
import StringIO
import csv



# Parse CSV
def createJson(data):

    rowData = []

    # Remove whitespace within field names
    fieldnames = ['Date', 'Holiday_Name', 'Information', 'More_Information', 'Applicable_To' ]


    # Convert string to file-type object for use with DictReader
    csvFile = StringIO.StringIO(data)
    csvData = csv.DictReader(csvFile, fieldnames=fieldnames)

    # Skip the header line
    csvData.next()


    for row in csvData:
        rowData.append(row)

    jsonData = json.dumps(rowData)

    return jsonData




