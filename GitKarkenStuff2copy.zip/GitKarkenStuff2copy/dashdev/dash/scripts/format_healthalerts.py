"""
Script to convert Health Alert rss feed to json
"""

import xml.dom.minidom
import json
import time
from datetime import date


# Parse XML filtering out unwanted data and convert to json
def createJson(data):
    # cleanedData = stripHtml(data)
    dom = xml.dom.minidom.parseString(data)

    # Get all "item" nodes
    items = dom.getElementsByTagName("item")

    # First create a python dictionary to store key value pairs
    pythonData = []
    incidentData = {}

    # Traverse child nodes within each item node
    for item in items:

        # Get the data from the xml nodes that we're interested in
        pubDate = item.getElementsByTagName("pubDate")[0].childNodes[0].data
        title = item.getElementsByTagName("title")[0].childNodes[0].data
        link = item.getElementsByTagName("link")[0].childNodes[0].data
        try:
            description = item.getElementsByTagName("description")[0].childNodes[0].data
        except:
            description = "No description available"
            continue

        # Strip timezone data from end of date
        pubDate = pubDate[:-6]

        # Convert long date/time format to short
        dateTuple = time.strptime(pubDate, "%a, %d %b %Y %H:%M:%S")
        pubDate = time.strftime("%d/%m/%Y %H:%M", dateTuple)
        pubDay = int(time.strftime("%d", dateTuple))
        pubMonth = int(time.strftime("%m", dateTuple))
        pubYear = int(time.strftime("%Y", dateTuple))

        # Only store alerts for the past 90 days
        today =  date.today()
        pubDay = date(pubYear, pubMonth, pubDay)
        timeDiff = str(today - pubDay)
        daysDiff = int(timeDiff[:-14])

        if(daysDiff <= 90):

            # Add data to python dictionaries
            incidentData['title'] = title
            incidentData['pubDate'] = pubDate
            incidentData['link'] = link
            incidentData['description'] = description

            pythonData.append(dict(incidentData))

    # Convert python dict to json
    jsonData = json.dumps(pythonData)

    return jsonData




