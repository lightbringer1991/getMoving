import urllib
import xml.dom.minidom
import math
import psycopg2
import json

"""
Script to retrieve, parse, reformat and save CFA rss feed
"""

# Define coordinates and radius distance for filtering incidents within a certain distance from Ballarat
ballaratLat = -37.56622
ballaratLong = 143.84957

ballaratLatRad = ballaratLat * (math.pi/180)
ballaratLongRad = ballaratLong * (math.pi/180)

# Radius currently set to 100km for development and debugging, as there is not always a current incident close to Ballarat
radiusDistance = 100 #km's

# Convert decimal to radians, necessary for distance calculations
def decimalToRadians(decimal):
	radians = decimal * (math.pi/180)
	return radians


# Calculate distance in km's between two locations
def getDistance(startLat, startLong, endLat, endLong):

	# Convert decimal latitude and longitude to radians
	startLat = decimalToRadians(startLat)
	startLong = decimalToRadians(startLong)
	endLat = decimalToRadians(endLat)
	endLong = decimalToRadians(endLong)

	distance = math.acos(math.sin(startLat) * math.sin(endLat) + math.cos(startLat) * math.cos(endLat) * math.cos(endLong - (startLong))) * 6371

	return distance

# Extract additional field data from description string
def getDescriptionElement(text, start, end):
	return text[text.find(start)+len(start):text.find(end)]

def getLastDescriptionElement(text, start):
	return text[text.find(start)+len(start):]

# Get rss feed from web site
response = urllib.urlopen('https://data.emergency.vic.gov.au/Show?pageId=getIncidentRSS')
html = response.read()

# Strip inner html formatting
noInnerTags = html.replace('&lt;strong&gt;', '')
noInnerTags = noInnerTags.replace('&lt;/strong&gt;', '')
noInnerTags = noInnerTags.replace('&lt;br&gt;', '')

# Parse XML
dom = xml.dom.minidom.parseString(noInnerTags)

# Get all "item" nodes
items = dom.getElementsByTagName("item")

# First create a python dictionary to store key value pairs
pythonData = []
incidentData = {}

# Traverse child nodes within each item node
for item in items:

	# First check the location so we are only processing incidents in and around Ballarat

	# Incident location info is buried within the description node so we need to extract the location info from the description text first.
	description = item.getElementsByTagName("description")[0].childNodes[0].data

	latStart = 'Latitude: '
	latEnd = 'Longitude: '
	latitude = getDescriptionElement(description, latStart, latEnd)

	longStart = 'Longitude: '
	longEnd = ''
	longitude = getLastDescriptionElement(description, longStart)

	# Calculate distance in km's from central Ballarat to the incident, rounded to 2 decimal places
	incidentDistance = round(getDistance(ballaratLat, ballaratLong, float(latitude), float(longitude)), 2)

	# Only process incidents within a certain radius from central Ballarat
	if(incidentDistance <= radiusDistance):

		# Get the data from the xml nodes that we're interested in
		pubDate = item.getElementsByTagName("pubDate")[0].childNodes[0].data
		title = item.getElementsByTagName("title")[0].childNodes[0].data
		link = item.getElementsByTagName("link")[0].childNodes[0].data

		# Get additional values we need out of description string
		statusStart = 'Status: '
		statusEnd = 'Size: '
		status = getDescriptionElement(description, statusStart, statusEnd)

		typeStart = 'Type: '
		typeEnd = 'Location: '
		incidentType = getDescriptionElement(description, typeStart, typeEnd)

		locationStart = 'Location: '
		locationEnd = 'Status: '
		location = getDescriptionElement(description, locationStart, locationEnd)


		# Add data to python dictionaries
		incidentData['title'] = title
		incidentData['pubDate'] = pubDate
		incidentData['link'] = link
		incidentData['status'] = status
		incidentData['type'] = incidentType
		incidentData['location'] = location

		pythonData.append(dict(incidentData))

print pythonData
# Convert python object to json
#jsonData = str(json.dumps(pythonData))
jsonData = json.dumps(pythonData)
#print jsonData



# DON'T RUN THIS UNTIL THE TILE SCRIPT CHANGES TO READ THE NEW FORMAT!!!!
"""
# Connect to the database
try:
    conn = psycopg2.connect("dbname='django' user='django' host='107.170.233.8' password='esCMsoQ00d'")
except:
    print "I am unable to connect to the database"

# Insert/update data
cur = conn.cursor()

# Query to update just the data field for the existing tile_data element
try:
	cur.execute("UPDATE dash_tile_data SET data=%s WHERE name='Emergency Alerts'", (jsonData,))
except Exception,e:
	print str(e)

# Commit changes to update the database
conn.commit()


cur.execute("SELECT * FROM dash_tile_data WHERE id=10")
rows = cur.fetchall()



print "\n*****   RSS DATA   ********:\n"
for row in rows:
    print "   ", row[2]
"""


