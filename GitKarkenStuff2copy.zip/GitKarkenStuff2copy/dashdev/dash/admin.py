from django.contrib import admin
from .models import Category, Tile, Tile_Data, Tile_tileData

admin.site.register(Category)
admin.site.register(Tile)
admin.site.register(Tile_Data)
admin.site.register(Tile_tileData)
